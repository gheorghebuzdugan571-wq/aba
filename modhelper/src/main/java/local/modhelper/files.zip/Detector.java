package local.modhelper;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Проверка сообщения по правилам. Возвращает нарушения, самое тяжёлое — первым. */
public final class Detector {
    private static final String B = "(?<![\\p{L}\\d])";

    private static Pattern w(String re) {
        return Pattern.compile(B + "(?:" + re + ")");
    }

    // ---- 3.7 мат (слова = 1 балл, фразы = 2 балла) ----
    private static final List<Pattern> MAT = List.of(
            w("ебанат\\p{L}*"), w("выебал\\p{L}*"), w("блядин\\p{L}*"), w("гандон\\p{L}*"),
            w("долбаеб\\p{L}*"), w("ебанько"), w("еблан\\p{L}*"), w("пидор\\p{L}*"), w("пидр\\p{L}*"),
            w("пиздабол\\p{L}*"), w("пипидастр\\p{L}*"), w("хуесос\\p{L}*"), w("хуйло"),
            w("шлюх\\p{L}*"), w("шалав\\p{L}*"));
    private static final List<Pattern> MAT_PHRASES = List.of(
            w("иди\\s+на\\s+хуй"), w("я\\s+ебал\\p{L}*"), w("го\\s+секс"),
            w("го\\s+в\\s+попочк\\p{L}*"), w("дам\\s+в\\s+рот"));

    // ---- 3.8 оскорбления ----
    private static final List<Pattern> INSULT = List.of(
            w("бомж\\p{L}*"), w("бездар\\p{L}*"), w("глуп(?:ый|ая|ое|ые|ого|ому)"), w("даун\\p{L}*"),
            w("дебил\\p{L}*"), w("додик\\p{L}*"), w("дурак\\p{L}*"), w("дура(?![\\p{L}\\d])"),
            w("дурень"), w("животн(?:ое|ые|ым)"), w("идиот\\p{L}*"), w("инвалид\\p{L}*"),
            w("козел"), w("козл\\p{L}*"), w("конченн?\\p{L}*"), w("лох(?:и|а|у|ов|ом|ам)?(?![\\p{L}\\d])"),
            w("мраз(?:ь|и|от\\p{L}*)"), w("лошар\\p{L}*"), w("негр\\p{L}*"), w("мартышк\\p{L}*"),
            w("нищ(?:ий|ая|ие|его|ему|им)"), w("нищеброд\\p{L}*"), w("немощ(?:ь|ный)"),
            w("обоссан\\p{L}*"), w("обезьян\\p{L}*"), w("оболтус\\p{L}*"), w("овощь(?![\\p{L}\\d])"),
            w("твар(?:ь|и)(?![\\p{L}\\d])"), w("туп(?:ой|ая|ое|ые|ица|ого|орыл\\p{L}*)"),
            w("чмо(?![\\p{L}\\d])"), w("чмошн\\p{L}*"), w("чтоб\\s+ты\\s+сдох"), w("кретин\\p{L}*"));

    // ---- прочее ----
    /** Буквы, разделённые пробелами/точками: "д е б и л", "д.е.б.и.л". */
    private static final Pattern SPACED = Pattern.compile("(?<![\\p{L}\\d])(?:\\p{L}[\\s.\\-_*,]+){3,}\\p{L}(?![\\p{L}\\d])");
    /** Слова-числа вроде 1000000000 или 1.000.000 — не спам. */
    private static final Pattern NUMBERISH = Pattern.compile("[\\d.,'_-]+");
    private static final Pattern SUICIDE = w("убей\\s*ся|убей\\s+себя|повес(?:ься|ь\\s+себя)|вскрой(?:ся|\\s+вены)|выпились|спрыгни\\s+с\\p{L}*|сдохни|сделай\\s+харакири");
    private static final Pattern ALT_F4 = Pattern.compile("alt\\s*\\+?\\s*f\\s*4");
    private static final Pattern BEG_PUNISH = w("(?:дай\\p{L}*|выдай\\p{L}*)\\s+(?:мне\\s+|себе\\s+)?(?:мут|бан)\\p{L}*|(?:замут\\p{L}*|забан\\p{L}*)\\s+(?:меня|себя)");
    private static final Pattern BEG_RES = w("(?:дай\\p{L}*|выдай\\p{L}*|подкин\\p{L}*|подар\\p{L}*|кинь|скинь)\\s+(?:мне\\s+)?(?:админк\\p{L}*|вип|випк\\p{L}*|донат\\p{L}*|привилеги\\p{L}*|ресурс\\p{L}*|алмаз\\p{L}*|денег|деньги|монет\\p{L}*)");
    private static final Pattern DISCORD = Pattern.compile("discord|дискорд|disc0rd|dis\\s*cord|(?<![\\p{L}\\d])(?:дс|ds)(?![\\p{L}\\d])|\\w{2,32}#\\d{4}");
    private static final Pattern AD = Pattern.compile("(?:https?://|www\\.)\\S+|\\b(?:(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(?::\\d{2,5})?\\b|\\b[a-z0-9-]{2,}\\.(?:ru|com|net|org|gg|su|fun|pro|io|me|xyz|club|top|online|site|tk|ml)\\b");
    private static final Pattern PARENT = w("(?:твою|твоей|твоя|твоим)\\s+(?:мать|мамк\\p{L}*|мамаш\\p{L}*|маму|мам[аы]|родител\\p{L}*)|(?:мать|мамк\\p{L}*|мамаш\\p{L}*|маму|мама)\\s+(?:твою|твоя|твоей)");
    private static final Pattern PARENT_STRONG = w("ебал\\p{L}*\\s+(?:твою\\s+)?(?:мать|маму|мамк\\p{L}*|мамаш\\p{L}*)");
    private static final Pattern NEG = w("говно\\p{L}*|говн\\p{L}*|гавн\\p{L}*|дерьм\\p{L}*|параш\\p{L}*|мусор\\p{L}*|помойк\\p{L}*|хуйн\\p{L}*|отстой|днищ\\p{L}*|скам|убог\\p{L}*|сосет\\p{L}*|сосат\\p{L}*|сдох\\p{L}*|умер\\p{L}*");
    private static final Pattern POLITICS = w("путин\\p{L}*|зеленск\\p{L}*|навальн\\p{L}*|трамп(?:а|у|ом|е)?(?![\\p{L}\\d])|байден\\p{L}*|бандер\\p{L}*|слава\\s+(?:украин\\p{L}*|росси\\p{L}*)|голосуй\\p{L}*");
    private static final Pattern THREAT = w("забаню|забаним|забанят|замучу|замутим|замутят|выдам\\s+(?:тебе\\s+)?(?:мут|бан)|получишь\\s+(?:мут|бан)");

    private final Config cfg;
    private final Pattern symbolSpam;
    private final Map<String, Deque<Sample>> history = new HashMap<>();

    private record Sample(long time, String norm, List<String> words) {}

    public Detector(Config cfg) {
        this.cfg = cfg;
        int n = Math.max(2, cfg.symbolRepeat);
        this.symbolSpam = Pattern.compile("([^\\p{L}\\d\\s])\\1{" + (n - 1) + ",}");
    }

    public List<Rule> check(String nick, String msg) {
        String low = msg.toLowerCase(Locale.ROOT).replace('ё', 'е');
        String cyr = toCyr(low);
        Set<Rule> hits = new LinkedHashSet<>();

        // 3.1 флуд: N+ одинаковых/ПОХОЖИХ сообщений от одного ника за окно времени.
        // Похожими считаются и слегка изменённые, и «шаблонные» (одна фраза, меняется последнее слово).
        String norm = collapse(cyr.replaceAll("[^\\p{L}]", ""));
        if (norm.length() > 120) norm = norm.substring(0, 120);
        List<String> words = words(cyr);
        if (history.size() > 1000) history.clear();
        long now = System.currentTimeMillis();
        long windowMs = Math.max(1, cfg.floodWindowSeconds) * 1000L;
        Deque<Sample> dq = history.computeIfAbsent(nick.toLowerCase(Locale.ROOT), k -> new ArrayDeque<>());
        while (!dq.isEmpty() && now - dq.peekFirst().time() > windowMs) dq.pollFirst();
        if (norm.length() >= 3) {
            int similar = 1;
            for (Sample sm : dq) {
                if (similarMsg(sm.norm(), sm.words(), norm, words)) similar++;
            }
            dq.addLast(new Sample(now, norm, words));
            while (dq.size() > 30) dq.pollFirst();
            if (similar >= Math.max(2, cfg.floodCount)) hits.add(Rule.R_3_1);
        }

        // 3.1 повторы ВНУТРИ одного сообщения: слова, фразы, предложения
        if (hasRepeats(words, cyr)) hits.add(Rule.R_3_1R);

        // 3.4 / 3.5
        if (isSymbolSpam(low)) hits.add(Rule.R_3_4);
        if (isCaps(msg)) hits.add(Rule.R_3_5);

        // 3.7 / 3.8
        // проверяем и обычный текст, и с «схлопнутыми» буквами (дебиииил), и с буквами через пробел (д е б и л)
        String coll = collapse(cyr);
        String spaced = joinSpaced(cyr);
        int mat = Math.max(matScore(cyr), matScore(coll)) + matScore(spaced);
        boolean insult = count(INSULT, cyr) > 0 || count(INSULT, coll) > 0 || count(INSULT, spaced) > 0;
        if (mat >= cfg.matThreshold) hits.add(Rule.R_3_7);
        if (insult || (mat > 0 && mat < cfg.matThreshold)) hits.add(Rule.R_3_8);
        boolean rude = insult || mat > 0;

        // 3.9
        if (SUICIDE.matcher(cyr).find()) hits.add(Rule.R_3_9);

        // 3.10 оскорбление проекта
        if (containsAny(cfg.projectNames, low, cyr) && (rude || NEG.matcher(cyr).find())) hits.add(Rule.R_3_10);

        // 4.x
        if (BEG_PUNISH.matcher(cyr).find()) hits.add(Rule.R_4_1);
        if (BEG_RES.matcher(cyr).find()) hits.add(Rule.R_4_2);
        if (ALT_F4.matcher(low).find()) hits.add(Rule.R_4_4);
        if (containsAny(cfg.foreignProjects, low, cyr)) hits.add(Rule.R_4_5);
        if (DISCORD.matcher(low).find()) hits.add(Rule.R_4_6);

        // 5.x
        Matcher m = AD.matcher(low);
        while (m.find()) {
            String found = m.group();
            boolean allowed = false;
            for (String d : cfg.allowedDomains) {
                if (found.contains(d.toLowerCase(Locale.ROOT))) { allowed = true; break; }
            }
            if (!allowed) { hits.add(Rule.R_5_1); break; }
        }
        if (PARENT_STRONG.matcher(cyr).find() || (PARENT.matcher(cyr).find() && (rude || NEG.matcher(cyr).find()))) {
            hits.add(Rule.R_5_4);
        }

        // 6.x
        if (POLITICS.matcher(cyr).find()) hits.add(Rule.R_6_1);
        if (THREAT.matcher(cyr).find()) hits.add(Rule.R_6_3);
        if (rude && containsAny(cfg.staffWords, low, cyr)) hits.add(Rule.R_6_4);
        if (rude && containsAny(cfg.youtuberNames, low, cyr)) hits.add(Rule.R_6_6);

        List<Rule> out = new ArrayList<>(hits);
        out.sort((a, b) -> Integer.compare(b.severity(), a.severity()));
        return out;
    }

    private static final Set<String> STOP = Set.of("на", "не", "что", "это", "как", "так", "все", "его", "для", "или",
            "но", "по", "за", "из", "от", "до", "он", "она", "они", "мы", "вы", "ты", "же", "бы", "ли", "то", "там",
            "тут", "если", "при", "про", "ну", "да", "нет", "вот", "уже", "еще", "мне", "меня", "тебя", "мой", "моя");

    /** Повторы внутри сообщения: слово подряд / много раз, повтор фразы из 2-3 слов, повтор предложений. */
    private boolean hasRepeats(List<String> words, String cyr) {
        int n = words.size();

        // одно и то же слово подряд ("ха ха ха", "привет привет привет")
        int run = 1;
        for (int i = 1; i < n; i++) {
            if (sameWord(words.get(i), words.get(i - 1))) {
                if (++run >= cfg.repeatWordThreshold) return true;
            } else {
                run = 1;
            }
        }

        // одно слово много раз по всему тексту (с учётом искажений: "купи", "купиии", "kупи")
        List<String> reps = new ArrayList<>();
        List<Integer> cnt = new ArrayList<>();
        for (String w : words) {
            if (w.length() < 3 || STOP.contains(w)) continue;
            int idx = -1;
            for (int k = 0; k < reps.size(); k++) {
                if (sameWord(reps.get(k), w)) { idx = k; break; }
            }
            if (idx < 0) { reps.add(w); cnt.add(1); } else cnt.set(idx, cnt.get(idx) + 1);
        }
        for (int c : cnt) if (c >= cfg.repeatWordThreshold) return true;

        // повтор фразы ("да нет да нет да нет", "купи донат дёшево купи донат дёшево")
        if (ngramRepeats(words, 2, 3) || ngramRepeats(words, 3, 2)) return true;

        // повтор предложений
        List<String> sents = new ArrayList<>();
        for (String part : cyr.split("[.!?;\\n]+")) {
            String x = collapse(part.replaceAll("[^\\p{L}]", ""));
            if (x.length() >= 6) sents.add(x);
            if (sents.size() >= 20) break;
        }
        for (int i = 0; i < sents.size(); i++) {
            int same = 1;
            for (int j = 0; j < sents.size(); j++) {
                if (i != j && similar(sents.get(i), sents.get(j))) same++;
            }
            if (same >= cfg.repeatSentenceThreshold) return true;
        }
        return false;
    }

    private boolean ngramRepeats(List<String> words, int size, int threshold) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i + size <= words.size(); i++) {
            List<String> sub = words.subList(i, i + size);
            boolean allSame = true;
            for (String x : sub) if (!x.equals(sub.get(0))) { allSame = false; break; }
            if (allSame) continue;
            String key = String.join(" ", sub);
            if (key.length() < 6) continue;
            if (map.merge(key, 1, Integer::sum) >= threshold) return true;
        }
        return false;
    }

    private static boolean sameWord(String a, String b) {
        return a.equals(b) || similar(a, b);
    }

    /** Схлопывает повторяющиеся подряд буквы: "приветттт" -> "привет". */
    private static String collapse(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        char prev = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != prev) sb.append(c);
            prev = c;
        }
        return sb.toString();
    }

    private static List<String> words(String cyr) {
        List<String> out = new ArrayList<>();
        for (String t : cyr.split("[^\\p{L}\\d]+")) {
            String c = collapse(t);
            if (c.length() >= 2) out.add(c);
        }
        return out;
    }

    /** 3.5: капсом N+ слов целиком, либо 50%+ букв заглавные при 3+ словах. */
    private boolean isCaps(String msg) {
        int words = 0, letters = 0, upper = 0, capsWords = 0;
        for (String tok : msg.split("\\s+")) {
            int tl = 0, tu = 0;
            for (int i = 0; i < tok.length(); i++) {
                char ch = tok.charAt(i);
                if (Character.isLetter(ch)) {
                    tl++;
                    if (Character.isUpperCase(ch)) tu++;
                }
            }
            if (tl > 0) {
                words++;
                letters += tl;
                upper += tu;
                if (tl >= 2 && tu == tl) capsWords++;
            }
        }
        if (capsWords >= Math.max(2, cfg.capsWords)) return true;
        return words >= 3 && letters > 0 && upper * 2 >= letters;
    }

    /** 3.4: !!!!, ////, и длинные «слова» из 1-3 разных символов (АХАХАХАХАХ, ПХПХПХПХХПХПХ, ыыыыыыыыыы). */
    private boolean isSymbolSpam(String low) {
        if (symbolSpam.matcher(low).find()) return true;
        for (String tok : low.split("\\s+")) {
            if (tok.length() < cfg.spamRunLength) continue;
            if (NUMBERISH.matcher(tok).matches()) continue;
            Set<Character> distinct = new HashSet<>();
            for (int i = 0; i < tok.length(); i++) distinct.add(tok.charAt(i));
            if (distinct.size() <= 3) return true;
        }
        return false;
    }

    private boolean similarMsg(String an, List<String> aw, String bn, List<String> bw) {
        if (an.equals(bn)) return true;
        int max = Math.max(an.length(), bn.length());
        if (max >= 6 && 1.0 - (double) levenshtein(an, bn) / max >= cfg.floodSimilarity) return true;
        return aw.size() >= 3 && bw.size() >= 3 && dice(aw, bw) >= cfg.floodWordSimilarity;
    }

    /** Доля совпавших слов (с поправкой на опечатки): 2*совпало / (слов в A + слов в B). */
    private static double dice(List<String> a, List<String> b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        boolean[] used = new boolean[b.size()];
        int matched = 0;
        for (String x : a) {
            for (int j = 0; j < b.size(); j++) {
                if (!used[j] && sameWord(x, b.get(j))) {
                    used[j] = true;
                    matched++;
                    break;
                }
            }
        }
        return 2.0 * matched / (a.size() + b.size());
    }

    private static int matScore(String text) {
        return count(MAT, text) + 2 * count(MAT_PHRASES, text);
    }

    private static String joinSpaced(String cyr) {
        Matcher m = SPACED.matcher(cyr);
        StringBuilder sb = new StringBuilder();
        while (m.find()) sb.append(m.group().replaceAll("[^\\p{L}]", "")).append(' ');
        return sb.toString();
    }

    private static int count(List<Pattern> list, String text) {
        int n = 0;
        for (Pattern p : list) {
            Matcher m = p.matcher(text);
            while (m.find()) n++;
        }
        return n;
    }

    private static boolean containsAny(List<String> words, String low, String cyr) {
        for (String raw : words) {
            if (raw == null || raw.isBlank()) continue;
            String wl = raw.toLowerCase(Locale.ROOT).replace('ё', 'е');
            if (low.contains(wl) || cyr.contains(toCyr(wl))) return true;
        }
        return false;
    }

    /** Латинские «двойники» -> кириллица, чтобы ловить обход вроде "дeбил" с латинской e. */
    private static String toCyr(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case 'a' -> sb.append('а');
                case 'c' -> sb.append('с');
                case 'e' -> sb.append('е');
                case 'o' -> sb.append('о');
                case 'p' -> sb.append('р');
                case 'x' -> sb.append('х');
                case 'y' -> sb.append('у');
                case 'k' -> sb.append('к');
                case 'm' -> sb.append('м');
                case 't' -> sb.append('т');
                default -> sb.append(c);
            }
        }
        return sb.toString();
    }

    private static boolean similar(String a, String b) {
        if (a.equals(b)) return true;
        int max = Math.max(a.length(), b.length());
        if (max < 4) return false;
        int d = levenshtein(a, b);
        return 1.0 - (double) d / max >= 0.8;
    }

    private static int levenshtein(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }
}
